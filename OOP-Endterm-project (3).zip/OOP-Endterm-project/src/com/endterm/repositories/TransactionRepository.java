package com.endterm.repositories;

import com.endterm.datа.interfaces.IDB;
import com.endterm.enteties.Card;
import com.endterm.enteties.Customer;

import java.math.BigDecimal;
import java.util.Scanner;

public class TransactionRepository {
    private final IDB db;
    private CardRepository card_repo;
    private Scanner sc=new Scanner(System.in);

    public TransactionRepository(IDB db){
        this.db=db;
        card_repo=new CardRepository(db);
    }

    public boolean setupMoneyInKZT(Customer user) {
        System.out.println(card_repo.getCustomerCards(user));
        System.out.println("Select bank card: ");
        int card_id = sc.nextInt();
        System.out.println("Enter card number: ");
        BigDecimal card_num = sc.nextBigDecimal();
        System.out.println("Enter sum: ");
        int sum = sc.nextInt();
        return card_repo.setKZTIntoCard(card_repo.getCustomerCards(user).get(card_id).getCard_number(), sum);
    }

    public boolean transferKZT(Customer user, Card card){
        System.out.println("Enter sum: ");
        int sum= sc.nextInt();
        return card_repo.setKZTIntoCard(card_repo.getCustomerCards(user).get(card.getId()).getCard_number(),card_repo.getCustomerCards(user).get(card.getId()).getMik()+sum);
    }
    public boolean transferRUB(Customer user, Card card){
        System.out.println("Enter sum: ");
        int sum= sc.nextInt();
        return card_repo.setRUBIntoCard(card_repo.getCustomerCards(user).get(card.getId()).getCard_number(),card_repo.getCustomerCards(user).get(card.getId()).getMir()+sum);
    }
    public boolean transferUSD(Customer user, Card card){
        System.out.println("Enter sum: ");
        int sum= sc.nextInt();
        return card_repo.setUSDIntoCard(card_repo.getCustomerCards(user).get(card.getId()).getCard_number(),card_repo.getCustomerCards(user).get(card.getId()).getMiu()+sum);
    }
}
