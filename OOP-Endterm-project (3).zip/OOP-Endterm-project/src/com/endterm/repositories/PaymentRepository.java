package com.endterm.repositories;

public class PaymentRepository {
}
