package com.endterm.repositories;

public class DepartmentRepository {

}
