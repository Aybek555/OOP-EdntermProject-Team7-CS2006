package com.endterm;

import com.endterm.controllers.ManagerController;
import com.endterm.datа.PostgresDB;
import com.endterm.datа.interfaces.IDB;
import com.endterm.repositories.ManagerRepository;

import java.sql.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

    }
}

