package com.endterm;

import com.endterm.datа.PostgresDB;
import com.endterm.datа.interfaces.IDB;
import com.endterm.enteties.Customer;
import com.endterm.repositories.CustomerRepository;

import java.sql.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        IDB db=new PostgresDB();
        CustomerRepository repo=new CustomerRepository(db);

    }
}

