package com.endterm.enteties;

public class Employee extends Person {
    private String occupation;
    private int salary;
    public Employee(String fname,String lname,String occupation,int salary, String iin,String phone,String address,int age){
        super(fname,lname,iin,phone,address,age);
        this.occupation=occupation;
        this.salary=salary;
    }

    public Employee(int id, String fname, String lname,String occupation,int salary, String iin, String phone_number, String address, int age) {
        super(id,fname,lname,iin,phone_number,address,age);
        this.occupation=occupation;
        this.salary=salary;
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
