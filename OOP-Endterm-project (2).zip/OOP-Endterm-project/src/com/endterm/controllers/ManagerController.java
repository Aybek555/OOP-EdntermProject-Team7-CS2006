package com.endterm.controllers;

import com.endterm.enteties.Department;
import com.endterm.enteties.Manager;
import com.endterm.repositories.ManagerRepository;

import java.util.List;

public class ManagerController {
    private final ManagerRepository repo;

    public ManagerController(ManagerRepository repo){
        this.repo=repo;
    }

    public String createManager(Department dep){
        boolean created= repo.createManager(dep);
        return (created ? "Manager was created successfully!" : "Creation was failed!");
    }

    public String getManagerByID(int id){
        Manager man= repo.getManagerByID(id);
        return (man!=null ? man.toString() : "Manager was not found!");
    }

    public String getManagerByIIN(String iin){
        Manager m= repo.getManagerByIIN(iin);
        return (m!=null ? m.toString() : "Manager was not found!");
    }

    public List<Manager> getAllManagers(){
        List<Manager> managers=repo.getAllManagers();
        return managers;
    }
}
