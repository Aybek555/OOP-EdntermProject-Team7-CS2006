package com.endterm;

import com.endterm.controllers.CustomerController;
import com.endterm.controllers.EmployeeController;
import com.endterm.controllers.ManagerController;
import com.endterm.datа.PostgresDB;
import com.endterm.datа.interfaces.IDB;
import com.endterm.enteties.Department;
import com.endterm.repositories.CustomerRepository;
import com.endterm.repositories.EmployeeRepository;
import com.endterm.repositories.ManagerRepository;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        IDB db = new PostgresDB();
        MyApplication application = new MyApplication(db);
        application.start();
    }
}


