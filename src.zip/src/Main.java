import java.sql.*;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        IDB db = new PostgresDB();
        Connection con = null;
        con = db.getConnection();
        Scanner sc = new Scanner(System.in);
        String sql = " insert into customer (customer_ID,fname,lname,phone_number,iin,address,age)"
                + " values (?, ?,?,?,?,?,?)";
        System.out.println("Enter id:");
        int id = sc.nextInt();
        System.out.println("Enter fname:");
        String fname = sc.next();
        System.out.println("Enter lname:");
        String lname = sc.next();
        System.out.println("Enter phone number:");
        int phoneNumber = sc.nextInt();
        System.out.println("Enter IIN:");
        int IIN = sc.nextInt();
        System.out.println("Enter address");
        String address = sc.next();
        System.out.println("Enter age:");
        int age = sc.nextInt();
        PreparedStatement preparedStmt = con.prepareStatement(sql);
        preparedStmt.setInt(1, id);
        preparedStmt.setString (2, fname);
        preparedStmt.setString (3, lname);
        preparedStmt.setInt (4, phoneNumber);
        preparedStmt.setInt (5, IIN);
        preparedStmt.setString (6, address);
        preparedStmt.setInt (7, age);
        preparedStmt.execute();
        System.out.println("A new stone was added");
        System.out.println("");
    }




    /*
        Customer:
        1.Registration
        2.Open deposit
        3.Do payments
        4.do transaction
        5.Take cash
        6.Register new wallet
     */


    /*
        Employee:
        1.Service
        2.DoJob
        3.Get list of customers
     */

    /*
        Manager:
        1.Hire employee
        2.Dismiss employee
        3.List all the employees
        4.Make holiday for employee
        5.Change employee's salary
     */


}
