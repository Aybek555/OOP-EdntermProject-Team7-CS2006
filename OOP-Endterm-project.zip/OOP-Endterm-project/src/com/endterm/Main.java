package com.endterm;

import com.endterm.controllers.ManagerController;
import com.endterm.datа.PostgresDB;
import com.endterm.datа.interfaces.IDB;
import com.endterm.enteties.Department;
import com.endterm.repositories.ManagerRepository;

import java.sql.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        IDB db=new PostgresDB();
        Scanner sc=new Scanner(System.in);
        Connection con = null;
        Department dep=new Department();
        dep.setId(1);
        dep.setName("Bank 44");
        try {
            con = db.getConnection();
            String sql = "INSERT INTO manager (fname,lname,age,iin,phone_number,address,department_id,salary) VALUES (?,?,?,?,?,?,?,?)";
            PreparedStatement ps = con.prepareStatement(sql);

            System.out.println("Enter manager name: ");
            String name = sc.next();
            ps.setString(1, name);

            System.out.println("Enter manager surname: ");
            String surname = sc.next();
            ps.setString(2, surname);

            System.out.println("Enter manager age: ");
            int age = sc.nextInt();
            ps.setInt(3, age);

            System.out.println("Enter manager iin: ");
            String iin = sc.next();
            ps.setString(4, iin);

            System.out.println("Enter manager phone: ");
            String phone = sc.next();
            ps.setString(5, phone);

            System.out.println("Enter manager address: ");
            String address = sc.next();
            ps.setString(6, address);

            ps.setInt(7,dep.getId());

            System.out.println("Enter manager salary: ");
            int salary=sc.nextInt();
            ps.setInt(8,salary);

        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (Exception e) {
                System.out.println("Some exception occurred: " + e);
            }
        }
    }
}

