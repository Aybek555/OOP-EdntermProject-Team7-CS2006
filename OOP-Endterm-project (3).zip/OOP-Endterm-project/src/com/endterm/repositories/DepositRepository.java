package com.endterm.repositories;

import com.endterm.datа.interfaces.IDB;
import com.endterm.enteties.Customer;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Scanner;

public class DepositRepository {
    private final IDB db;
    private Scanner sc=new Scanner(System.in);
    public DepositRepository(IDB db){
        this.db=db;
    }

    public boolean openDeposit(Customer user){
        Connection con=null;
        SimpleDateFormat date=new SimpleDateFormat("MM/dd/yyyy");
        String date1=date+"";
        try{
            con=db.getConnection();
            String sql="INSERT INTO Deposit (name,percent_rate,amountofmoney,date1,customer_id) VALUES (?,?,?,?,?);";
            PreparedStatement ps=con.prepareStatement(sql);
            System.out.println("Choose option: \n1 Open Deposit\n2 Open Loan\n3 Open Mortgage");
            int option=sc.nextInt();
            if(option==1){
             ps.setString(1,"Deposit");
             ps.setInt(2,5);
             System.out.println("Final amount?");
             ps.setInt(3,sc.nextInt());
            }else if(option==2){
                ps.setString(1,"Loan");
                ps.setInt(2,10);
                System.out.println("How much do you want to apply for a loan?");
                ps.setInt(3,sc.nextInt());
            }else if(option==3){
                ps.setString(1,"Mortgage");
                ps.setInt(2,10);
                System.out.println("How much do you want to apply for a mortgage?");
                ps.setInt(3,sc.nextInt());
            }
            ps.setString(4,date1);
            ps.setInt(5,user.getId());
        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }
        return false;
    }
}
