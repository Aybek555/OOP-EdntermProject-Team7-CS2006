package com.endterm.repositories;

import com.endterm.datа.interfaces.IDB;
import com.endterm.enteties.Customer;
import com.endterm.repositories.interfaces.ICustomerInterface;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class CustomerRepository implements ICustomerInterface {
    private final IDB db;
    private Scanner sc = new Scanner(System.in);

    CustomerRepository(IDB db) {
        this.db = db;
    }

    @Override
    public boolean createCustomer() {
        Connection con = null;
        try {
            con = db.getConnection();
            String sql = "INSERT INTO customer (fname,lname,age,iin,phone_number,address) VALUES (?,?,?,?,?,?)";
            PreparedStatement ps = con.prepareStatement(sql);
            System.out.println("Enter your name: ");
            String name = sc.next();
            ps.setString(1, name);
            System.out.println("Enter your surname: ");
            String surname = sc.next();
            ps.setString(2, surname);
            System.out.println("Enter your age: ");
            int age = sc.nextInt();
            ps.setInt(3, age);
            System.out.println("Enter your iin: ");
            String iin = sc.next();
            ps.setString(4, iin);
            System.out.println("Enter your phone: ");
            String phone = sc.next();
            ps.setString(5, phone);
            System.out.println("Enter your address: ");
            String address = sc.next();
            ps.setString(6, address);
            return true;
        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (Exception e) {
                System.out.println("Some exception occurred: " + e);
            }
        }
        return false;
    }


    @Override
    public Customer getCustomerByID(int id) {
        Connection con = null;
        try {
            con = db.getConnection();
            String sql = "SELECT * FROM customer where customer_id=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Customer user = new Customer(rs.getInt("customer_id"), rs.getString("fname"), rs.getString("lname"), rs.getString("iin"), rs.getString("phone_number"), rs.getString("address"), rs.getInt("age"));
                return user;
            }
        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (Exception e) {
                System.out.println("Some exception occurred: " + e);
            }
        }
        return null;
    }

    @Override
    public Customer getCustomerByIIN(String iin) {
        Connection con = null;
        try {
            con = db.getConnection();
            String sql = "SELECT * FROM customer where iin=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, iin);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Customer user = new Customer(rs.getString("fname"), rs.getString("lname"), rs.getString("iin"), rs.getString("phone_number"), rs.getString("address"), rs.getInt("age"));
                return user;
            }
        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (Exception e) {
                System.out.println("Some exception occurred: " + e);
            }
        }
        return null;
    }

    @Override
    public List<Customer> getAllCustomers() {
        Connection con = null;
        try {
            con = db.getConnection();
            String sql = "SELECT * FROM customer";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            List<Customer> users = new ArrayList<>();
            while (rs.next()) {
                Customer user = new Customer(rs.getInt("customer_id"), rs.getString("fname"), rs.getString("lname"), rs.getString("iin"), rs.getString("phone_number"), rs.getString("address"), rs.getInt("age"));
                users.add(user);
            }
            return users;
        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (Exception e) {
                System.out.println("Some exception occurred: " + e);
            }
        }
        return null;
    }
}
